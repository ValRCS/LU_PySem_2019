#!/bin/sh

ffmpeg -i input1.mkv -ss 6 -to 29 -c:v copy -c:a copy 1.mkv
ffmpeg -i input1.mkv -ss 32 -to 49 -c:v copy -c:a copy 2.mkv
ffmpeg -i input1.mkv -ss 53 -to 71 -c:v copy -c:a copy 3.mkv
ffmpeg -i input1.mkv -ss 75 -c:v copy -c:a copy 4.mkv
